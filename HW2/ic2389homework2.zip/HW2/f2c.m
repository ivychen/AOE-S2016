% Ivy Chen | ic2389 | AOE Spring 2016

%Problem 4
function cel = f2c(f)
cel = (f - 32)*(5/9);

