% fuTV (ex-Wildcats) |  AOE Spring 2106
% Ivy Chen
% Shannon Diesch
% Sameer Jain
% Bryan Lei
% 
% Gets current channel number

function c = getCurrChannel()
global tv;
c = tv.currChannel;
end