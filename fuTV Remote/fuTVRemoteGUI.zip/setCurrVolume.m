% fuTV (ex-Wildcats) |  AOE Spring 2106
% Ivy Chen
% Shannon Diesch
% Sameer Jain
% Bryan Lei
%
% Sets current volume

function setCurrVolume(val)
global tv;
tv.currVolume = val;
end