% fuTV (ex-Wildcats) |  AOE Spring 2106
% Ivy Chen
% Shannon Diesch
% Sameer Jain
% Bryan Lei
% 
% Gets last channel number

function c = getLastChannel()
global tv;
c = tv.lastChannel;
end