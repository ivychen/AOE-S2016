% fuTV (ex-Wildcats) |  AOE Spring 2106
% Ivy Chen
% Shannon Diesch
% Sameer Jain
% Bryan Lei
%
% Sets current channel

function setCurrChannel(val)
global tv;
tv.currChannel = val;
end