% fuTV (ex-Wildcats) |  AOE Spring 2106
% Ivy Chen
% Shannon Diesch
% Sameer Jain
% Bryan Lei
%
% Sets last channel viewed

function setLastChannel(c)
global tv;
tv.lastChannel = c;
end