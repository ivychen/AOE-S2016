% Ivy Chen | ic2389 | AOE Spring 2016

%Problem 5
function far = c2f(c)
far = ((c)*(5/9)) + 32;

