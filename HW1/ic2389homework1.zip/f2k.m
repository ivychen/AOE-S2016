% Ivy Chen | ic2389 | AOE Spring 2016

%Problem 6
function k = f2k(f)
c = f2c(f);
k = c + 273.15;

